package diasdelasemana;
import java.util.Scanner;

public class DiasDeLaSemana {

    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
       System.out.println("Ingrese el número del día de la semana: ");
       int dia = in.nextInt();
       String diaString;
       switch (dia)
       {
           case 1: diaString = "El día es Lunes";
           break;
           case 2: diaString = "El día es Martes";
           break;
           case 3: diaString = "El día es Miércoles";
           break;
           case 4: diaString = "El día es Jueves";
           break;
           case 5: diaString = "El día es Viernes";
           break;
           case 6: diaString = "El día es Sábado";
           break;
           case 7: diaString = "El día es Domingo";
           break;
           default: diaString = "Día inválido, la semana solamente tiene 7 días crack";
           break;
           
       }
           System.out.println(diaString);
       
    }
    
}