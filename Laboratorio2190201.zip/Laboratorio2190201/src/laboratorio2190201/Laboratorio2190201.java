package laboratorio2190201;
import java.util.Scanner;


public class Laboratorio2190201 {

    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de notas que quiere promediar: ");
        float cantidad = in.nextFloat();
        float suma = 0;
        int cont = 1;
        for(float i=1; i<=cantidad;i++)
            {
            System.out.println("Ingrese nota "+cont);
            float notas = in.nextFloat();
            if(notas<=5 && notas>=0)
            
            {
                suma = suma + notas;
                cont++;
            }
            else
            {
                System.out.println("La última nota no es válida");
                i--;
            }
            }                           
        
        float promedio = suma/cantidad;
        
        System.out.println("El promedio de las notas es: " +promedio);
      
        
            
        
        
        
 
    }
    
}