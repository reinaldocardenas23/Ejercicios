package programa2;
import java.util.Scanner;
public class Programa2 {

   public static void main(String[] args) 
   {
         Scanner in = new Scanner(System.in);
         
         System.out.println("Ingrese el primer número: ");
         float a = in.nextFloat();
         System.out.println("Ingrese el segundo número: ");
         float b = in.nextFloat();
         System.out.println("Ingrese el tercer número: ");
         float c = in.nextFloat();
         
         
         if(a==b & b==c)
         {
             System.out.println("Los tres números son iguales ");
         }
         else if(a==b & b!=c)
         {
             System.out.println("Los números 'a' "+a+ " y " +b+ " 'b' son iguales" );
         }
         else if(a==c & b!=c)
         {
             System.out.println("Los números 'a'"+" "+a+" "+ "y" +" " +c+" "+ "'c' son iguales");
             
         }
         else if(b==c & a!=c)
         {
             System.out.println("Los números b " +b+ "y " +c+ "c son iguales");
             
         }
         else if (a!=b & a!=c & b!=c)
         {
             System.out.println("Los tres números son diferentes ");
         }
         
    }
    
}